<?php

/**********************************************************
* Author: Mary Hurley
*
* Todo.php : This file is the entry point of the server code for the Todo web App
* So here basically once the client calls the server ( once the app is opened )
* an instance is created of Todo class which will create an instance of the db class. 
* Any Todos that are in the db are listed .
* The $_SERVER array is parsed to see what request has come from the client and the 
* appropriate method is called :
*                    if POST then addTodo method will be called with appropriate params
*                       PUT  then updateTodo with the ID and 
*                       DELETE then deleteTodo method
*
*
* Had to uses file_get_contents and json_decode functions to get the params passed from 
* the client side. (I was initially trying to access the params from the $POST array 
* but the data was not there, or not in the correct format, and as time was slipping I sought 
* a different solution and that is - file_get and json_decode. )
*
* Assignment: WE4.1 Server-side Web Development assignment, Digital Skills Academy
* Student ID: D15128601
* Date : 2016/10/06
* Ref: website link to code referenced or the book, authors name and page number
* https://scotch.io/tutorials/submitting-ajax-forms-the-angularjs-way
* https://codeforgeek.com/2014/07/angular-post-request-php/
* http://php.net/manual/en/mysqli.real-escape-string.php
* http://www.w3resource.com/php/super-variables/$_SERVER.php
***********************************************************/

include('TodoDB.class.php');
include('Todo.class.php');

 // initialise variables

    $name = NULL;
    $job = NULL;
   
   
    $todo = new Todo();
    if ($todo != false )
        $todo->listTodos();             //Display whats in the db

// Collect details from Angular HTTP Request.   

    $postdata = file_get_contents("php://input");
    $request = json_decode($postdata);
    @$name = $request->name;
    @$job = $request->job;
    @$id = $request->id;
    @$done = $request->done;             
    
    switch ($_SERVER['REQUEST_METHOD']) {
  // handle the appropriate request   
        case 'POST' : 
            if ( ($name != NULL) && ($job != NULL) ) {   
                $todo->addTodo($name, $job);
            }
            break;

        case 'PUT'  : 
            $todo->updateTodo($id, $done);
            break;
            
            
        case 'DELETE': 
            $todo->deleteTodo($id);
            break;

    }
   
?>
