/*
*
*
* Author : Mary Hurley
* Assignment : WE4.1 Mobile Web Application, Digital Skills Academy
* Tite : Angular ToDo App
* Student ID: D15128601
* Date: 2016/09/01
* 
* This is the main code set for the Todo app. The controllers and routing are set up here.
* There are 2 controllers here the TodoController and the sortController.
*
* Modified : 2016/10/06 to implement web service and database functionality for SSWD assignment.
* Added a TodoService to handle http requests to the server :
*          getTodo (get), addTodo (post), updateTodo (put) and removeTodo (delete)
* These functions will be called from the controller to handle the http calls. 
* Setup $q to deal with promises. ( needed more time to work this out : )
*
* Code Ref/Reuse: website link to code referenced or the book, authors name and page number
*
* http://www.w3schools.com/angular/tryit.asp?filename=try_ng_todo_app 
* https://scotch.io/tutorials/single-page-apps-with-angularjs-routing-and-templating
* http://www.bogotobogo.com/AngularJS/AngularJS_multiviews_ng-app_ngRoute_config_routeProvider-templateUrl_ng-view.php
*
* additions for SSWD assignmnet : 2016/10/06 
*
* http://angularcode.com/simple-task-manager-application-using-angularjs-php-mysql/
* https://scotch.io/tutorials/submitting-ajax-forms-the-angularjs-way
* http://stackoverflow.com/questions/15485354/angular-http-post-to-php-and-undefined
* https://codeforgeek.com/2014/07/angular-post-request-php/
* https://codeforgeek.com/2014/09/two-way-data-binding-angularjs/
* https://www.bennadel.com/blog/2612-using-the-http-service-in-angularjs-to-make-ajax-requests.htm
* http://stackoverflow.com/questions/19496821/clicking-a-checkbox-with-ng-click-does-not-update-the-model
*/

var app = angular.module("Todo", ['ngRoute']).
    config(function($routeProvider) {
        
            $routeProvider
            .when('/Todo', {
                templateUrl: 'partials/Todo.html',
                controller: 'TodoController'
            })
            .when('/sort', {
                templateUrl: 'partials/sort.html',
                controller: 'sortController'
            })
            .otherwise({
                redirectTo: '/Todo'
            });
});


/* code reuse : 
 * https://www.bennadel.com/blog/2612-using-the-http-service-in-angularjs-to-make-ajax-requests.htm
 */

app.service('TodoService', function($http, $q){    
    return({
            getTodo: getTodo,
            addTodo: addTodo,
            updateTodo:updateTodo,
            removeTodo: removeTodo
            });
    
    function getTodo(){
        
        var request = $http({
            method:"get",
            url:"ajax/Todo.php",
            params:{
                action:"get"
            }
        });
    
        return(request.then (handleSuccess, handleError));
        
    }

    function addTodo(data){
        
        var request = $http({
            method:"post",
            url:"ajax/Todo.php",
            params:{
                action:"add"
            },
            data:data
        });
    
        return(request.then (handleSuccess, handleError));     
    
    }
    
     function updateTodo(data){
        
        var request = $http({
            method:"put",
            url:"ajax/Todo.php",
            params:{
                action:"update"
            },
            data: data
        });
    
        return(request.then (handleSuccess, handleError));

    }
    
    function removeTodo(id){
        
        var request = $http({
            method:"delete",
            url:"ajax/Todo.php",
            params:{
                action:"delete"
            },
            data: id
        });
    
        return(request.then (handleSuccess, handleError));

    }
    
    function handleError( response ) {
    // The API response from the server should be returned in a
    // nomralized format. However, if the request was not handled by the
    // server (or what not handles properly - ex. server error), then we
    // may have to normalize it on our end, as best we can.
        if (
            ! angular.isObject( response.data ) ||
            ! response.data.message
            ) {
                return( $q.reject( "An unknown error occurred." ) );
            }
            // Otherwise, use expected error message.
                return( $q.reject( response.data.message ) );
        }
    
    // I transform the successful response, unwrapping the application data
    // from the API response payload.
    
    function handleSuccess( response ) {
        return( response.data );
        }
    }
);

app.controller("TodoController", function($scope, TodoService) {   
    
    $scope.title = "What's To Do..." ;
    $scope.todoData = [];

    
    loadRemoteTodos();   // Display whats in the database from a get call
   
    $scope.addTodo = function() { 
        TodoService.addTodo({ name :$scope.inputName, job:$scope.inputJob})
                .then(
                    loadRemoteTodos,
                    function(errorMessage) {
                       console.warn(errorMessage);    // just logging to the console for now
                  });
        $scope.inputName = "";                   
        $scope.inputJob = ""; 

    };
    
    $scope.removeTodo = function(todo) {
        var oldData = $scope.todoData;
        $scope.todoData = [];                   // get rid of the todo from the view 
        angular.forEach(oldData, function(todo) {
            if (!todo.done) {
                $scope.todoData.push(todo);
            }
            else {
                TodoService.removeTodo({id:todo.todoId});   // and remove it from the db
            }
        });
    };
    
    $scope.updateTodo = function(todo) {        
        TodoService.updateTodo({id:todo.todoId, done:todo.done}); 
    }; 
   
    
    // load the remote todos from  server.
    function loadRemoteTodos() {
        // The friendService returns a promise.
        TodoService.getTodo()
            .then(
                function( TodoService) {
                    $scope.todoData = TodoService;
                });
    };
});
            
app.controller('sortController', function($scope, TodoService) {
    $scope.title = "Who's Doing What..." ;
    
    TodoService.getTodo()
            .then(function(TodoService){
                $scope.Todos = TodoService;
                $scope.sort = "todoName";
                $scope.setSort= function(type){$scope.sort = type};
            });    
});
